package hust.cs.javacourse.search.parse.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleFilter;
import hust.cs.javacourse.search.parse.AbstractTermTupleStream;
import hust.cs.javacourse.search.util.StopWords;

public class StopWordTermTupleFilter extends AbstractTermTupleFilter{

    private List<String> stopWord;
    /**
     * 构造函数
     * @param input : 输入流
     * */
    public StopWordTermTupleFilter(AbstractTermTupleStream input) {
        super(input);
        this.stopWord = new ArrayList<String>(Arrays.asList(StopWords.STOP_WORDS));
    }
    /**
     * 获得下一个三元组
     *过滤掉停等词
     * @return: 下一个三元组；如果到了流的末尾，返回null
     */
    @Override
    public AbstractTermTuple next() {
        AbstractTermTuple tmp=input.next();
        if(tmp==null){
            return null;
        }
        else{
            for(;tmp!=null;tmp=input.next()){
                if(!stopWord.contains(tmp.term.getContent()))break;
            }
            return tmp;
        }
    }
    
}
