package hust.cs.javacourse.search.parse.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.index.impl.Term;
import hust.cs.javacourse.search.index.impl.TermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleScanner;
import hust.cs.javacourse.search.util.Config;
import hust.cs.javacourse.search.util.StringSplitter;

public class TermTupleScanner extends AbstractTermTupleScanner{
    private int pos=0;
    private List<TermTuple> list=new ArrayList<>();
    /**
     * 获得当前位置
     */
    public int getPos() {
        return pos;
    }
    /**
     * 设置当前位置
     * @param pos: 要设置的当前位置
     */
    public void setPos(int pos) {
        this.pos = pos;
    }
    /**
     * 获得获取到的三元组列表
     */
    public List<TermTuple> getList() {
        return list;
    }
    /**
     * 对输入的BufferReader对象进行扫描获取其中的三元组
     * @param input
     */
    public TermTupleScanner(BufferedReader input){
        super(input);
        String tmp;
        // this.pos=0;
        try {
            tmp = input.readLine();
            for(;tmp!=null;tmp=input.readLine()){
                StringSplitter tool=new StringSplitter();
                tool.setSplitRegex(Config.STRING_SPLITTER_REGEX);
                List<String> list=new ArrayList<>();
                list=tool.splitByRegex(tmp);
                for(int i=0;i<list.size();i++){ // TODO SPLITTER?
                    if(list.get(i).equals(" ")){
                        continue;
                    }
                    else {
                        this.list.add(new TermTuple(new Term(list.get(i).toLowerCase()),this.pos++));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.pos=0;
    }
    /**
     * 获取下一个元素
     */
    @Override
    public AbstractTermTuple next() {
        if (this.pos<this.list.size()){
            TermTuple ans=list.get(this.pos);
            this.pos++;
            return ans;
        } else {
            return null;
        }
    }
    
    
}
