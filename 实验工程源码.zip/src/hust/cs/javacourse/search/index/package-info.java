/**
 * hust.cs.javacourse.search.index包里定义了和倒排索引数据结构相关的抽象类，以及和索引构建相关的抽象类和接口.
 * 学生需要实现这些抽象类和接口的具体子类
 */
package hust.cs.javacourse.search.index;