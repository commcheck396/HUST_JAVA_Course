package hust.cs.javacourse.search.index.impl;

import hust.cs.javacourse.search.index.AbstractTerm;

public class TermTuple extends hust.cs.javacourse.search.index.AbstractTermTuple{
    /**
     * 获得Term
     */
    public AbstractTerm getTerm(){
        return this.term;
    }
    /**
     * 获得频率
     */
    public int getFreq(){
        return this.freq;
    }
    /**
     * 获得当前位置
     */
    public int getCurPos(){
        return this.curPos;
    }
    /**
     * 设置Term
     * @param term: 要设置的Term
     */
    public void setTerm(AbstractTerm term) {
        this.term = term;
    }
    /**
     * 设置当前位置
     * @param curPos: 当前位置
     */
    public void setCurPos(int curPos) {
        this.curPos = curPos;
    }

    /**
     * 缺省构造函数
     */
    public TermTuple() {
    }
    /**
     * 使用term和curPos来构造TermTuple
     * @param term ：单词
     * @param curPos ：位置
     */
    public TermTuple(Term term, int pos) {
        this.term = term;
        this.curPos = pos;
    }

    /**
     * 判断二个三元组内容是否相同
     *
     * @param obj ：要比较的另外一个三元组
     * @return 如果内容相等（三个属性内容都相等）返回true，否则返回false
     */
    @Override
    public boolean equals(Object obj) {
        if(this.term.equals(((TermTuple) obj).getTerm())&&this.freq==((TermTuple) obj).getFreq()&&this.curPos==((TermTuple) obj).getCurPos())return true;
        else return false;
    }
    /**
     * 获得三元组的字符串表示
     *
     * @return ： 三元组的字符串表示
     */
    @Override
    public String toString() {
        String tmp=this.getTerm().toString();
        System.out.println(tmp+this.getCurPos()+this.getFreq());
        return (String)(tmp+this.getCurPos()+this.getFreq());
    }
    
}

