package hust.cs.javacourse.search.index.impl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Term extends hust.cs.javacourse.search.index.AbstractTerm{
    /**
     * 构造函数
     *
     * @param content ：Term内容
     */
    public Term(String content) {
        this.content = content;
    }
    /**
     * 缺省构造函数
     */
    public Term(){
        
    }
    /**
     * 判断二个Term内容是否相同
     * @param obj ：要比较的另外一个Term
     * @return 如果内容相等返回true，否则返回false
     */
    @Override
    public boolean equals(Object obj){
        // int len1=0;
        // int len2=0;
        java.lang.String str1=this.toString();
        java.lang.String str2=obj.toString();
        // len2=obj.toString().length();
        // len1=this.toString().length();
        if(str1.compareTo(str2)!=0)return false;
        else return true;

    }
    /**
     * 返回Term的字符串表示
     * @return 字符串
     */
    @Override
    public String toString() {
        System.out.println(this.content);
        return this.content;
    }
    /**
     * 返回Term内容
     * @return Term内容
     */
    public String getContent(){
        return this.content;
    }
    /**
     * 设置Term内容
     * @param content：Term的内容
     */
    public void setContent(String content){
        this.content=content;
    }
    /**
     * 比较二个Term大小（按字典序）
     * @param o： 要比较的Term对象
     * @return ： 返回二个Term对象的字典序差值
     */
    public int compareTo(hust.cs.javacourse.search.index.AbstractTerm o) {
        // int len1=0;
        // int len2=0;
        java.lang.String str1=this.toString();
        java.lang.String str2=o.toString();
        return str1.compareTo(str2);
    //     len2=o.toString().length();
    //     len1=this.toString().length();
    //     for(int i=0;i<len1&&i<len2;i++){
    //         if(str1.charAt(i)==str2.charAt(i))continue;
    //         else return str1.charAt(i)-str2.charAt(i);
    //     }
    //     if(len1!=len2)return len1-len2;
    //     else return 0;
    }

    /**
     * 写到二进制文件
     * @param out :输出流对象
     */
    @Override
    public void writeObject(ObjectOutputStream out) {
        try {
            out.writeObject(this.content);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    /**
     * 从二进制文件读
     * @param in ：输入流对象
     */
    @Override
    public void readObject(ObjectInputStream in) {
        try {
            this.content=(String) in.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
}

