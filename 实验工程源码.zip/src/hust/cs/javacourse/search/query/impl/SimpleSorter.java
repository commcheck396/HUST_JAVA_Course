package hust.cs.javacourse.search.query.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.naming.ldap.SortKey;

import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.query.AbstractHit;
import hust.cs.javacourse.search.query.Sort;

public class SimpleSorter implements Sort{

    @Override
    public void sort(List<AbstractHit> hits) {
        Collections.sort(hits, Comparator.reverseOrder());
        
    }

    @Override
    public double score(AbstractHit hit) {
        double ans=0;
        Set<AbstractTerm> mark =hit.getTermPostingMapping().keySet();
        Iterator it=mark.iterator();
        for(;it.hasNext();){
            ans+=hit.getTermPostingMapping().get(it.next()).getFreq();
        }
        return ans;
    }
    
}
