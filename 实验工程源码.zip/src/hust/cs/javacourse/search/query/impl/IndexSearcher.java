package hust.cs.javacourse.search.query.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import hust.cs.javacourse.search.index.AbstractPosting;
import hust.cs.javacourse.search.index.AbstractPostingList;
import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.query.AbstractHit;
import hust.cs.javacourse.search.query.AbstractIndexSearcher;
import hust.cs.javacourse.search.query.Sort;

public class IndexSearcher extends AbstractIndexSearcher{
    public IndexSearcher() {
    }
    /**
     * 从指定索引文件打开索引，加载到index对象里. 一定要先打开索引，才能执行search方法
     *
     * @param indexFile ：指定索引文件
     */
    @Override
    public void open(String indexFile) {
        this.index.load(new File(indexFile));
    }
    /**
     * 根据单个检索词进行搜索
     *
     * @param queryTerm ：检索词
     * @param sorter    ：排序器
     * @return ：命中结果数组
     */
    @Override
    public AbstractHit[] search(AbstractTerm queryTerm, Sort sorter) {
        AbstractPostingList list=this.index.search(queryTerm);
        if(list==null){
            return null;
        }
        else {
                int len=list.size();
                ArrayList<AbstractHit> hits = new ArrayList<>();
                for(int i=0;i<len;i++){
                    Map<AbstractTerm, AbstractPosting> posMap = new HashMap<>();
                    AbstractPosting pos=list.get(i);
                    posMap.put(queryTerm,pos);
                    hits.add(new Hit(pos.getDocId(), this.index.getDocName(pos.getDocId()),posMap));
                    hits.get(i).setScore(sorter.score(hits.get(i)));
                }
            sorter.sort(hits);
            return hits.toArray(new AbstractHit[hits.size()]);
        }
    }
    /**
     * 根据二个检索词进行搜索
     *
     * @param queryTerm1 ：第1个检索词
     * @param queryTerm2 ：第2个检索词
     * @param sorter     ：    排序器
     * @param combine    ：   多个检索词的逻辑组合方式
     * @return ：命中结果数组
     */
    @Override
    public AbstractHit[] search(AbstractTerm queryTerm1, AbstractTerm queryTerm2, Sort sorter,
            LogicalCombination combine) {
                AbstractPostingList list1 = this.index.search(queryTerm1);
                AbstractPostingList list2 = this.index.search(queryTerm2);

                ArrayList<AbstractHit> hits = new ArrayList<>();
                if(combine.equals("OR")){
                    if (list1 != null) {
                        for (int i = 0; i < list1.size(); i++) {
                            Map<AbstractTerm, AbstractPosting> posmap = new HashMap<>();
                            AbstractPosting posting = list1.get(i);
                            posmap.put(queryTerm1, posting);
                            hits.add(new Hit(posting.getDocId(), this.index.getDocName(posting.getDocId()), posmap)); 
                            hits.get(i).setScore(sorter.score(hits.get(i)));
                        }
                    }
                    if (list2 != null) {
                        for (int i = 0; i < list2.size(); i++) {
                            Map<AbstractTerm, AbstractPosting> posmap = new HashMap<>();
                            int flag = 0;
                            AbstractPosting posting = list2.get(i);
                            for (int j = 0; j < hits.size(); j++) {
                                AbstractHit tmp = hits.get(j);
                                if (tmp.getDocId() == posting.getDocId()) {
                                    tmp.getTermPostingMapping().put(queryTerm2, posting);
                                    tmp.setScore(sorter.score(tmp));
                                    flag = 1;
                                }
                            }
                            if (flag == 0) {
                                posmap.put(queryTerm2, posting);
                                hits.add(new Hit(posting.getDocId(), this.index.getDocName(posting.getDocId()), posmap));
                                hits.get(hits.size()-1).setScore(sorter.score(hits.get(hits.size()-1)));
                            }
                        }
                    }
                }
                else if(combine.equals("AND")){
                    if (list1 != null && list2 != null) {
                        for (int i = 0; i < list1.size(); i++) {
                            AbstractPosting posting1 = list1.get(i);
                            for (int j = 0; j < list2.size(); j++) {
                                Map<AbstractTerm, AbstractPosting> posmap = new HashMap<>();
                                AbstractPosting posting2 = list2.get(j);
                                if (posting1.getDocId() == posting2.getDocId()) {
                                    posmap.put(queryTerm1, posting1);
                                    posmap.put(queryTerm2, posting2);
                                    hits.add(new Hit(posting1.getDocId(), this.index.getDocName(posting1.getDocId()), posmap));
                                    hits.get(hits.size()-1).setScore(sorter.score(hits.get(hits.size()-1)));
                                }
                            }
                        }
                    }
                }
                else {
                    System.out.println("error");
                }
        
                sorter.sort(hits);
                return hits.toArray(new AbstractHit[hits.size()]);
    }
    /**
     * 进阶功能，检索词组
     *
     * @param queryTerm1 ：第1个检索词
     * @param queryTerm2 ：第2个检索词
     * @param sorter     ：    排序器
     * @return ：命中结果数组
     */
    public AbstractHit[] search(AbstractTerm queryTerm1, AbstractTerm queryTerm2, Sort sorter){
        AbstractPostingList list1 = this.index.search(queryTerm1);
        AbstractPostingList list2 = this.index.search(queryTerm2);
        ArrayList<AbstractHit> hits = new ArrayList<>();
        if(list1==null||list2==null){
            return null;
        }
        else {
            int len1=list1.size();
            int len2=list2.size();
            for(int i=0;i<len1;i++){
                int doc1=list1.get(i).getDocId();
                for(int j=0;j<len2;j++){
                    int doc2=list2.get(j).getDocId();
                    if(doc1!=doc2){
                        continue;
                    }
                    else {
                        for(int p=0;p<list1.get(i).getFreq();p++){
                            int pos1=list1.get(i).getPositions().get(p);
                            for(int q=0;q<list2.get(j).getFreq();q++){
                                Map<AbstractTerm, AbstractPosting> posmap = new HashMap<>();
                                int pos2=list2.get(j).getPositions().get(q);
                                if(pos2!=pos1+1){
                                    continue;
                                }
                                else{
                                    posmap.put(queryTerm1, list1.get(i));
                                    posmap.put(queryTerm2, list2.get(j));
                                    hits.add(new Hit(list1.get(i).getDocId(), this.index.getDocName(list1.get(i).getDocId()), posmap));
                                    hits.get(hits.size()-1).setScore(sorter.score(hits.get(hits.size()-1)));
                                }
                            }
                        }
                        // TODO to optimize
                    }
                }
            }
            sorter.sort(hits);
            return hits.toArray(new AbstractHit[hits.size()]);
        }
    }
}
